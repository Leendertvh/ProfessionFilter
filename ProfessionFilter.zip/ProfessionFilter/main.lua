EngineeringFilter = {}
EngineeringFilterSaved = EngineeringFilterSaved or {}

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")

local searchBox
local suggestionFrame
local suggestions = {}

local function IsProfessionOpen()
    if not TradeSkillFrame or not TradeSkillFrame:IsShown() then return false end
    local prof = GetTradeSkillLine()
    -- We willen de filter voor alle professions, dus altijd true als tradeskill open is
    return true
end

local function ExpandAllHeaders()
    local numSkills = GetNumTradeSkills()
    for i = 1, numSkills do
        local name, skillType, _, _, _, _, _, expanded = GetTradeSkillInfo(i)
        if skillType == "header" and not expanded then
            ExpandTradeSkillSubClass(i)
        end
    end
end

local function CollapseAllHeaders()
    local numSkills = GetNumTradeSkills()
    for i = 1, numSkills do
        local name, skillType, _, _, _, _, _, expanded = GetTradeSkillInfo(i)
        if skillType == "header" and expanded then
            CollapseTradeSkillSubClass(i)
        end
    end
end

local function UpdateFilter()
    if not IsProfessionOpen() then return end

    local query = searchBox:GetText():lower()
    if query == "search..." or query == "" then
        CollapseAllHeaders()
        TradeSkillFrame_Update()
        if suggestionFrame then suggestionFrame:Hide() end
        return
    end

    ExpandAllHeaders()

    local numSkills = GetNumTradeSkills()
    local firstMatchIndex = nil
    suggestions = {}

    for i = 1, numSkills do
        local name, skillType = GetTradeSkillInfo(i)
        if skillType ~= "header" then
            local frame = _G["TradeSkillSkill"..i]
            if name and name:lower():find(query) then
                if frame then frame:Show() end
                if not firstMatchIndex then
                    firstMatchIndex = i
                end
                table.insert(suggestions, name)
            else
                if frame then frame:Hide() end
            end
        end
    end

    if firstMatchIndex then
        TradeSkillFrame_SetSelection(firstMatchIndex)
    end

    TradeSkillFrame_Update()
    UpdateSuggestionFrame()
end

-- Suggestion buttons
local suggestionButtons = {}

function UpdateSuggestionFrame()
    if not suggestionFrame or #suggestions == 0 then
        if suggestionFrame then suggestionFrame:Hide() end
        return
    end

    local maxSuggestions = 5
    local count = math.min(#suggestions, maxSuggestions)

    for i = 1, maxSuggestions do
        local btn = suggestionButtons[i]
        if i <= count then
            btn:SetText(suggestions[i])
            btn:Show()
        else
            btn:Hide()
        end
    end

    suggestionFrame:SetHeight(count * 20)
    suggestionFrame:Show()
end

local function OnSuggestionClick(self)
    local text = self:GetText()
    if text then
        searchBox:SetText(text)
        searchBox:SetFocus()
        UpdateFilter()
    end
    if suggestionFrame then suggestionFrame:Hide() end
end

local function CreateSuggestionFrame()
    if suggestionFrame then return end

    suggestionFrame = CreateFrame("Frame", "ProfessionFilterSuggestionFrame", TradeSkillFrame)
    suggestionFrame:SetSize(200, 100)
    suggestionFrame:SetPoint("TOPLEFT", searchBox, "BOTTOMLEFT", 0, -2)
    suggestionFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    suggestionFrame:Hide()
    suggestionFrame:SetFrameLevel(searchBox:GetFrameLevel() + 5)

    for i = 1, 5 do
        local btn = CreateFrame("Button", nil, suggestionFrame)
        btn:SetSize(200, 20)
        btn:SetPoint("TOPLEFT", suggestionFrame, "TOPLEFT", 0, -(i - 1) * 20)
        btn:SetNormalFontObject("GameFontHighlightSmall")
        btn:SetHighlightFontObject("GameFontHighlightSmall")
        btn:SetScript("OnClick", OnSuggestionClick)

        btn.text = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        btn.text:SetAllPoints()
        btn.text:SetJustifyH("LEFT")

        suggestionButtons[i] = btn
    end
end

local function CreateSearchBox()
    if searchBox then
        searchBox:Show()
        return
    end

    searchBox = CreateFrame("EditBox", "ProfessionFilterSearchBox", TradeSkillFrame, "InputBoxTemplate")
    searchBox:SetSize(200, 20)
    searchBox:SetPoint("TOPLEFT", TradeSkillRankFrame, "BOTTOMLEFT", 0, -5) -- 3 pixels hoger dan -8
    searchBox:SetAutoFocus(false)
    searchBox:SetText("Search...")
    searchBox:SetScript("OnEditFocusGained", function(self)
        if self:GetText() == "Search..." then self:SetText("") end
    end)
    searchBox:SetScript("OnEditFocusLost", function(self)
        if self:GetText() == "" then self:SetText("Search...") end
    end)
    searchBox:SetScript("OnTextChanged", function(self)
        UpdateFilter()
    end)

    CreateSuggestionFrame()
end

local function OnTradeSkillShow()
    C_Timer.After(0.1, function()
        if IsProfessionOpen() then
            CreateSearchBox()
            UpdateFilter()
        elseif searchBox then
            searchBox:Hide()
            if suggestionFrame then suggestionFrame:Hide() end
        end
    end)
end

f:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == "ProfessionFilter" then
        self:RegisterEvent("TRADE_SKILL_SHOW")
    elseif event == "TRADE_SKILL_SHOW" then
        OnTradeSkillShow()
    end
end)
