-- EngineeringFilter ui.lua
local function IsEngineeringOpen()
    if not TradeSkillFrame or not TradeSkillFrame:IsShown() then return false end
    local prof = GetTradeSkillLine()
    return prof == "Engineering"
end

local searchBox

local function CreateSearchBox()
    if searchBox then return end

    searchBox = CreateFrame("EditBox", "EngineeringFilterSearchBox", TradeSkillFrame, "InputBoxTemplate")
    searchBox:SetSize(200, 20)
    searchBox:SetPoint("TOPRIGHT", TradeSkillFrame, "TOPRIGHT", -40, -35)
    searchBox:SetAutoFocus(false)
    searchBox:SetScript("OnTextChanged", function(self)
        local text = self:GetText():lower()
        for i = 1, GetNumTradeSkills() do
            local name, type = GetTradeSkillInfo(i)
            local frame = _G["TradeSkillSkill"..i]
            if frame then
                if type == "header" or name:lower():find(text) then
                    frame:Show()
                else
                    frame:Hide()
                end
            end
        end
    end)
    searchBox:Show()
end

hooksecurefunc("TradeSkillFrame_Update", function()
    if IsEngineeringOpen() then
        CreateSearchBox()
    elseif searchBox then
        searchBox:Hide()
    end
end)
